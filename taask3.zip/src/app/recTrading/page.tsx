import React from 'react'

const page = () => {
  return (
    <div>
            Welcome to the REC TRADING!
    </div>
  )
}

export default page
