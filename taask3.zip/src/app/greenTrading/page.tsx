import React from 'react'

const page = () => {
  return (
    <div>
            Welcome to the GREEN TRADING!

    </div>
  )
}

export default page
