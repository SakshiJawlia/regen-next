import { FieldErrors, FieldValues, UseFormRegister } from 'react-hook-form'

interface Props{
    name:string,
    type:string,
    label:string,
    placeholder:string,
    required?:boolean,
    register: UseFormRegister<FieldValues>;
    errors: FieldErrors;
    pattern?:any,
    widthFull?:boolean,
    className?:string,
    minLength?:number,
}

export const Input = ({name,type,label,placeholder,required,register,errors,pattern,widthFull,className,minLength}:Props) => {
  return (
         <label htmlFor={name}
         className='flex flex-col gap-3'>
            <p className='text-[#555555] text-sm font-bold'>{label}</p>
            <input type={type} 
                placeholder={placeholder}
                {...register(
                    name,
                    {
                        required: required,
                        pattern : pattern, 
                        minLength: minLength
                    }
                )}
                className={`p-4 outline-none border border-[#F2F2F2] ${widthFull && 'w-full'} ${errors[name] && 'bg-red-100 text-error'}}`}
            />
            {errors[name] && <span>{label} not present</span>}
        </label>
  )
}
