export const navlinks=[
    {
        title:'Your Account',
        href:'/'
    },
    {
        title:'My Dashboard',
        href:'/myDashboard'
    },
    {
        title:'Fuel Trading',
        href:'fuelTrading'
    },
    {
        title:'Green Trading',
        href:'greenTrading'
    },
    {
        title:'REC Trading',
        href:'recTrading'
    },

]