const items=[
    {
        id:'1',
        name:'Green Methanol',
        percent:"99%",
        price:"$21/kg",
        avail:"yes"
    },
    {
        id:'2',
        name:'Blue Ammonia',
        percent:"99%",
        price:"$10/kg",
        avail:"no"
    },
    {
        id:'3',
        name:'Grey Hydrogen',
        percent:"99%",
        price:"$23/kg",
        avail:"yes"
    },
    {
        id:'4',
        name:'Green Ammonia',
        percent:"99%",
        price:"$19/kg",
        avail:"no"
    },
    {
        id:'5',
        name:'Grey Ammonia',
        percent:"99%",
        price:"$15/kg",
        avail:"yes"
    },
    {
        id:'6',
        name:'Grey Ammonia',
        percent:"99%",
        price:"$15/kg",
        avail:"yes"
    },
    {
        id:'7',
        name:'Grey Ammonia',
        percent:"99%",
        price:"$15/kg",
        avail:"yes"
    },
    {
        id:'8',
        name:'Grey Ammonia',
        percent:"99%",
        price:"$15/kg",
        avail:"yes"
    }
]
export default items;