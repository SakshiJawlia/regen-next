interface Product{
    id:string,
    name:string
}

const product:Product[]=[
    {
        id:"1",
        name:"Yellow Ammonia",
    },
    {
        id:"2",
        name:"Grey Ammonia",
    },
    {
        id:"3",
        name:"Green Methanol",
    },
    {
        id:"4",
        name:"Blue Hydrogen",
    },
]
export default product;