import React from 'react'
import Button from '../common/Button';
import { Heading } from '../common/Heading';
import { FieldErrors, FieldValues, UseFormClearErrors, UseFormGetValues, UseFormRegister, UseFormSetError } from 'react-hook-form';
import { Input } from '../common/Input';

interface Props{
  register:UseFormRegister<FieldValues>,
  errors:FieldErrors<FieldValues>,
  getValues:UseFormGetValues<FieldValues>,
  setError:UseFormSetError<FieldValues>,
  clearErrors:UseFormClearErrors<FieldValues>,
  successHandler:()=>void,
}

export const SignUpStep1 = ({register,errors,getValues,setError,clearErrors,successHandler}:Props) => {

  return (
    <form >
    <div className='bg-white rounded-2xl'>
     <div className='flex gap-10 flex-col px-10 py-14'>
       <Heading text="Buyer Details"/>
       <Input type='text'
               name='firstName'
               label='First Name'
               placeholder='john'
               required
               widthFull
               errors={errors}
               register={register}
               />
         <Input type='text'
                 name='lastName'
                 placeholder='christ'
                 required
                 errors={errors}
                 widthFull
                 register={register}
                 label='Last Name'
                 />
          <Input type='text'
                  name='email'
                  label='Email ID'
                  placeholder='john@1234'
                  required
                  pattern={/^\S+@\S+$/i} 
                  widthFull
                  errors={errors}
                  register={register}
                  />
             <Input type='password'
                    name='Newpassword'
                    placeholder='8+ characters'
                    required
                    errors={errors}
                    minLength={8}
                    widthFull
                    register={register}
                    label='New Password'
                    />
            <Input type='password'
                    name='confirmPassword'
                    placeholder='8+ characters'
                    required
                    errors={errors}
                    minLength={8}
                    widthFull
                    register={register}
                    label='Confirm Password'
                    />
          <div className='flex gap-5'>
           <Button text="Cancel"
                 bg="bg-[#F2F2F2]"
                 type="submit"
                 textColor="black"/>
           <Button text="Verify Now"
                 bg="bg-[#023047]"
                 type="submit"
                 textColor="white"
                 onClick={successHandler}/>
      </div>
     </div>
   </div>
 </form>
  )
}
