import React from 'react'
import Button from '../common/Button';
import { Heading } from '../common/Heading';
import { FieldErrors, FieldValues, UseFormClearErrors, UseFormGetValues, UseFormRegister, UseFormSetError } from 'react-hook-form';
import { Input } from '../common/Input';
import { InputOTPDemo } from '../common/OTP';


interface Props{
  register:UseFormRegister<FieldValues>,
  errors:FieldErrors<FieldValues>,
  getValues:UseFormGetValues<FieldValues>,
  setError:UseFormSetError<FieldValues>,
  clearErrors:UseFormClearErrors<FieldValues>,
  successHandler:()=>void,
}

export const SignUpStep2 = ({register,errors,getValues,setError,clearErrors,successHandler}:Props) => {
  return (
    <form >
      <div className='bg-white rounded-2xl'>
        <div className=' px-10 py-12 w-[]'>
          <div className='flex flex-col gap-3'>
            <Heading text="OTP Verification"/>
            <p className='text-sm text-[#555555]'>You will receive a mail with otp to verify your email address :: xyz@gmail.com</p>
            <button className='text-sm text-[#555555] border-b border-black w-fit font-medium'>Resend OTP</button>
          </div>
          <div className='py-10'>
            <InputOTPDemo/>
          </div>
          <div className='flex gap-5'>
           <Button text="Back"
                 bg="bg-[#F2F2F2]"
                 type="submit"
                 textColor="black"/>
           <Button text="Submit"
                 bg="bg-[#023047]"
                 type="submit"
                 textColor="white"
                 onClick={successHandler}/>
          </div>
        </div>
      </div>
    </form>





    // <form>
    //    <div className='bg-white rounded-2xl'>
    //     <div className='flex flex-col gap-3'>
    //       <Heading text="OTP Verification"/>
    //       <p>You will receive a mail with otp to verify your email address :: xyz@gmail.com</p>
    //       <p className='border border-b'>Resend OTP</p>
    //     </div>
    //     <div className='flex flex-col gap-5'>
    //       <p>Enter OTP</p>
    //       <InputOTPDemo/>
    //     </div>
    //         <div className='flex gap-5'>
    //           <Button text="Back"
    //                 bg="bg-[#F2F2F2]"
    //                 type="submit"
    //                 textColor="black"/>
    //           <Button text="Log In"
    //                 bg="bg-[#023047]"
    //                 type="submit"
    //                 textColor="white"
    //                 onClick={successHandler}/>
    //         </div>
    //   </div>
    // </form>
  )
}
